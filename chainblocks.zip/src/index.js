import React from 'react'
import ReactDOM from 'react-dom'
import './index.css'
import Alpha from './Alpha'

ReactDOM.render(<Alpha />, document.getElementById('root'))
