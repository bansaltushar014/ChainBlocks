import React from 'react'
import ReactDOM from 'react-dom'
import './css/index.css'
import Alpha from './Alpha'

ReactDOM.render(<Alpha />, document.getElementById('root'))
